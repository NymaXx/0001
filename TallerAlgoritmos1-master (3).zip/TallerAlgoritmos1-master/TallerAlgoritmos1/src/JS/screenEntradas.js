class screenEntradas{
    constructor(){

    }

    paint(){
        image(e,0,0,width,height);
    }

    
}