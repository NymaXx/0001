class screenSpecial{
    constructor(){

    }

    paint(){
        image(o,0,0,width,height);
    }

    
}