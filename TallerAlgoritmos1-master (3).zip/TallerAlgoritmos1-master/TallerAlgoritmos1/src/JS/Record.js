class Record{
    constructor(){
        
    }
}