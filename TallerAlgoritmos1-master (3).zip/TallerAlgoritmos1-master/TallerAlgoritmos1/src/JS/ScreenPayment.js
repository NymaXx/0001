class ScreenPayment{
    constructor(){
        this.cardInput= new Input();
        this.securityCodeInput= new Input();
        this.adressInput= new Input(); 
        this.cityInput=  new Input();
        this.dateInput= new Input();
        this.nameInput= new Input();

    }

    focusInputs(){

    }

    writeTextInput(){

    }

    paint(){
        image(i, 0,0, width, height);
    }
}