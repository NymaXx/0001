class screenFast{
    constructor(){

    }

    paintFace(){
        image(f,0,0,width,height);
    }

    
}