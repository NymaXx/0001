class ResumeScreen{
    constructor(){
        this.dd =  day();
        this.mm =  month();
        this.yyyy =  year();

    }

    


    hoyFecha(){

        text(""+ this.dd + "/" + this.mm + "/"+ this.yyyy,332,630,55,55);
        
    }

    paintFace(){
        image(k, 0,0, width, height);
    }

    continueButton(){
        if(mouseX >= 300 && mouseX <= 482 && mouseY>= 859 && mouseY <=935){
            screen= 11;
        }else{
            screen =10;
        }
    }


}