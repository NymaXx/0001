let screen;
var screenR;
var screenL;
var screenP;
var screenPay;
var screenRec;
var screenO;
var resumeScreen;
var screenProf;
var screenFastt;
var screenDess;
var screenSpeciall;
var screenEntrada;
let a, b, c, d, e, f, g, h, i, j, k, l, m, n, o;
var modal1, modal2;
let biutton, addi;
//inputs

let result="";
let loginScreen;
let valid;


function preload(){
a= loadImage("data/login.png"); //0
b= loadImage("data/registro.png") //1
c= loadImage("data/home.png"); //2
d= loadImage("data/perfil.png"); //3
e= loadImage("data/entradas.png");  //4
f= loadImage("data/rapidos.png");  //5
g= loadImage("data/postres.png");  //6
h= loadImage("data/realizarpedido.png");  //7
i= loadImage("data/pago.png");  //8
j= loadImage("data/confirmar pedido.png");  //9
k= loadImage("data/resumenPedido.png"); //10 
l= loadImage("data/historialLLenar.png");  //11
m= loadImage("data/adiciones.png");  //12
n= loadImage("data/platilloEnchiladas.png"); //el resumen y descripcion del platillo enchiladas
o= loadImage("data/especial.png"); //resumen y descripcion del platillo especial tico

/*no se realizaron las pantallas e interacciones con los demas platillos en interes de simplicidad 
del codigo*/

}


function setup(){
    createCanvas(750,1334);
    screen=0;
    screenFastt= new screenFast();
    screenEntrada= new screenEntradas();
    screenDess = new screenDessert();
    screenSpeciall = new screenSpecial();
    screenR = new ScreenRegister([4],"pepe");
    biutton= new Button();
    addi= new Addition();

    //pantalla login
    
    loginScreen=new ScreenLogin([2],"pepe");
    user= new User("pepe","12345","jujuuju","1234567", "23556","cali","");

    screenP = new ScreenPrincipal();
    screenPay = new ScreenPayment();
    screenRec = new ScreenRecord();
    screenO = new ScreenOrder();
    resumeScreen = new ResumeScreen();
    screenProf= new screenProfile();
    modal1 = new Modal();

     
}

function draw(){
    background(255);
   
    switch(screen){
        case 0: // pantalla del LOGIN
        loginScreen.paintFace();
            loginScreen.paint();
            
            
            loginScreen.focusInputs(mouseX, mouseY);
		
		if(valid==true) {
			console.log("entro");
		}

            break;

        case 1:// pantalla de registro
            
            screenR.paintFace();
            screenR.paint();
            screenR.focusInputs(mouseX, mouseY);

            break;

        case 2://pantalla del HOME o INICIO 
            screenP.paintFace();
            break;

        case 3:// pantalla de seleccion de perfil
            screenProf.paintFace();
            break;

        case 4: // pantalla de seleccion de platillo ENTRADAS
            screenEntrada.paintFace();
            break;

        case 5:// pantalla de seleccion de platillo RAPIDOS
            screenFastt.paintFace();
            break;

        case 6:// pantalla de seleccion de platillo POSTRES 
            screenDess.paintFace();
            break;

        case 7: //pantalla de ORDENAR 
            screenO.paintFace();
            
            break;

        case 8: //pantalla de PAGO
            screenPay.paintFace();
            
            break;

        case 9: 

            break;

        case 10: //pantalla dE RESUMEN DEL PEDIDO
                resumeScreen.paintFace();
                resumeScreen.hoyFecha();
            break;

        case 11: // pantalla de  HISTORIAL
            screenRec.paintFace();
            break;


        case 12: //ADICIONES       
            addi.paintFace();

            break;

        case 13: 

            break;

        case 14: //pantalla de PLATILLO ESPECIAL
            screenSpeciall.paintFace();
            break;


    }
    
    textSize(19);
    text("X"+mouseX +" "+ "Y"+mouseY,mouseX,mouseY);

}


function mousePressed(){
    switch(screen){
        case 0: // pantalla del LOGIN
            loginScreen.goHome();
            loginScreen.goRegister();
            //boton de entrar
            if(mouseX>=138 && mouseX<=361 && mouseY>=1021 && mouseY<=1095 && loginScreen.valid()) {
                valid=true;
                console.log(valid);
                }
            
            
            break;

            case 1:// pantalla de registro
            screenR.toLoginBack();
            break;

        case 2://pantalla del HOME o INICIO 
            biutton.goBar();
            biutton.goTypesOfFood();
            console.log("true");
            break;

        case 3:// pantalla de perfil
            biutton.goBar();
            biutton.logOut();
            if(biutton.logOut()){
                //que se reinicie
            }
            break;

        case 4: // pantalla de seleccion de platillo ENTRADAS
            biutton.goBar();
            break;

        case 5:// pantalla de seleccion de platillo RAPIDO
            biutton.goBar();
            biutton.selectSupremeN(); 
             
            break;

        case 6:// pantalla de seleccion de platillo POSTRES 
            biutton.goBar();
            break;

        case 7: //pantalla de ORDENAR 
            
            biutton.goBar();
            biutton.addAdition();
            biutton.payment();
            
            break;

        case 8: //pantalla de PAGO
            biutton.goBar();
            biutton.resumeButton();
            break;

        case 9: 

            break;

        case 10: //pantalla de RESUMEN
        biutton.goBar();
            resumeScreen.continueButton();
            
            break;

        case 11: // pantalla de HISTORIAL
             biutton.goBar();

            break;

        case 12: 
            biutton.backAddi();
                

            break;

        case 13: 

            break;

        case 14: //pantalla de PLATILLO ESPECIAL
            biutton.goBar();
            biutton.buyTicosAlaDiabla();
            break;

     

        

    }

}

function keyPressed(){
    //login
    console.log(key);
    if(key !=BACKSPACE) {
    loginScreen.writeTextInput(key);
    
    }
    //register
    if(key !=BACKSPACE) {
        screenR.writeTextInput(key);
    }


    //console.log(loginScreen.eraseTextInput);
    //if(key=BACKSPACE){
    //loginScreen.eraseTextInput();}
}