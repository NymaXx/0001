class ScreenLogin{

    constructor(inputArraylist,user){
        this.inputArraylist= inputArraylist;
        this.inputArraylist=[];
        this.user=user;
        this.user= new User("Felipe Garcia","12345","jujuuju","1234567", "23556","cali","");
        this.inputArraylist = [];
        
        let incrementPosY=0;
        for(let i=0; i<2; i++) {
            this.inputArraylist[i] = new Input(258,785+incrementPosY,false,"");
            incrementPosY+=90;
        }
        
       
    
    }
    
    
    paint() {
        for(let i=0; i<this.inputArraylist.length;i++) {
            this.inputArraylist[i].paint();
            //console.log("pintar");
        }
    }
    
    focusInputs(mouseX, mouseY) {
        for(let i=0; i<this.inputArraylist.length;i++){
            if(mouseX>=this.inputArraylist[i].getPosX() && mouseX<= this.inputArraylist[i].getPosX() +200
                    && mouseY>this.inputArraylist[i].getPosY() && mouseY<= this.inputArraylist[i].getPosY()+30) {
                this.inputArraylist[i].setFocus(true);
            }else {
    
               this.inputArraylist[i].setFocus(false);
            }	
            }
        }
    
    writeTextInput(key) {
        
    
            if(this.inputArraylist[0].isFocus() && this.inputArraylist[0].getText().length<15) {
                this.inputArraylist[0].setText(this.inputArraylist[0].getText()+ key);
                }
    
            if(this.inputArraylist[1].isFocus() && this.inputArraylist[1].getText().length<15) {
                    this.inputArraylist[1].setText(this.inputArraylist[1].getText()+ key);
                    }
                
            }
            
            
           
        
        
    eraseTextImput() { 
        console.log(this)
        for(let i=0;i< this.inputArraylist.length;i++) {
            if(this.inputArraylist[i].isFocus() && this.inputArraylist[i].getText().length-1>=0) {
                let indice= this.inputArraylist[i].getText().length-1;
                this.inputArraylist[i].setText(this.inputArraylist[i].getText().substring(0,indice));
                }
            }
            
        }
        
    
    //funcion de validar nombre y contraseña
    //problema en esta parte 
        
    valid() {
        console.log(this);
        
        if(user.login(this.inputArraylist[0].getText()) && user.password(this.inputArraylist[1].getText())) {
                 return true;
                
                
        } else {
                 return false;
             }
        }
    

    paintFace(){
        image(a, 0,0, width, height);
    }

    goHome(){
        if(mouseX >= 140 && mouseX <= 360 && mouseY >= 1019 && mouseY <= 1099 ){
            screen = 2;
        }
    }

    goRegister(){
        if(mouseX >= 386 && mouseX <= 599 && mouseY >= 1019 && mouseY <= 1099 ){
            screen = 1;
        }
    }
}