class ScreenOrder{
    constructor(biutton){
        this.biutton=biutton;
    }

    IncludeAddition(){
       
    }

    totalPrice(){

    }

    paintFace(){
        image(h,0,0,width, height);
    }
}