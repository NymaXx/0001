class screenDessert{
    constructor(){

    }

    paintFace(){
        image(g,0,0,width,height);
    }

    
}