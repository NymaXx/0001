class ScreenRecord{
    constructor(){
        
    }

    paintFace(){
        image(l,0,0,width,height);
        }
}