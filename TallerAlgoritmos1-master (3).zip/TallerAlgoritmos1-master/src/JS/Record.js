class Record{
    constructor(){
        
    }
}