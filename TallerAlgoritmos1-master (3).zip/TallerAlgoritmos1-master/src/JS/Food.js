class Food{
    constructor(foodName, foodDescrip, price){
        this.foodName = foodName;
        this.foodDescrip = foodDescrip;
        this.price = price;
    }

    paint(){
        
    }

   //crear un arreglo de comidas con las dos comidas que es posible comprar
}