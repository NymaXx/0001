class screenSpecial{
    constructor(){

    }

    paintFace(){
        image(o,0,0,width,height);
    }

    
}