class ScreenRegister{
  
    constructor(inputArraylist,user){
        this.inputArraylist= inputArraylist;
        this.inputArraylist=[];
        this.user=user;
        this.user= new User("Felipe Garcia","12345","jujuuju","1234567", "23556","cali","");
        this.inputArraylist = [];
        
        let incrementPosY=0;
        for(let i=0; i<4; i++) {
            this.inputArraylist[i] = new Input(268,590+incrementPosY,false,"");
            incrementPosY+=90;
        }
    }

    paint(){
        for(let i=0; i<this.inputArraylist.length;i++) {
            this.inputArraylist[i].paint();
            //console.log("pintar");
        }
    }

    focusInputs(mouseX, mouseY) {
        for(let i=0; i<this.inputArraylist.length;i++){
            if(mouseX>=this.inputArraylist[i].getPosX() && mouseX<= this.inputArraylist[i].getPosX() +200
                    && mouseY>this.inputArraylist[i].getPosY() && mouseY<= this.inputArraylist[i].getPosY()+30) {
                this.inputArraylist[i].setFocus(true);
            }else {
    
               this.inputArraylist[i].setFocus(false);
            }	
            }
        }
    
    writeTextInput(key) {
            if(this.inputArraylist[0].isFocus() && this.inputArraylist[0].getText().length<15) {
            this.inputArraylist[0].setText(this.inputArraylist[0].getText()+ key);
            }

            if(this.inputArraylist[1].isFocus() && this.inputArraylist[1].getText().length<15) {
                this.inputArraylist[1].setText(this.inputArraylist[1].getText()+ key);
                }

        
    
            if(this.inputArraylist[2].isFocus() && this.inputArraylist[2].getText().length<15) {
                this.inputArraylist[2].setText(this.inputArraylist[2].getText()+ key);
                }

            if(this.inputArraylist[3].isFocus() && this.inputArraylist[3].getText().length<15) {
                this.inputArraylist[3].setText(this.inputArraylist[3].getText()+ key);
                }
    
           
                
            }

    paintFace(){
        image(b, 0,0, width, height);
    }

    validateRegister(){
        
    }

    toLoginBack(){
        if(mouseX >= 264 && mouseX <= 484 && mouseY >= 1070 && mouseY <= 1152 ){
            screen = 0;
        }
    }

    
}