class screenEntradas{
    constructor(){

    }

    paintFace(){
        image(e,0,0,width,height);
    }

    
}