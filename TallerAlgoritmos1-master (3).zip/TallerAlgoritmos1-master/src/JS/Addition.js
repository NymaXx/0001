class Addition{
    constructor(addiName, addiDescrip, addiprice, addiCant){
        this.addiName = addiName;
        this.addiDescrip = addiDescrip;
        this.addiprice = addiprice;
        this.addiCant = addiCant;
    }

    paintFace(){
        image(m,0,0,width,height);
    }

    upCant(){
        this.addiCant= 0;
        if(mouseX >= 118 && mouseX <= 135 && mouseY >=523 && mouseY <= 543){
            text(" "+this.addiCant--,140,527, 10,10);
            
        }
    }
}