class Addition{
    constructor(addiName, addiDescrip, addiprice){
        this.addiName = addiName;
        this.addiDescrip = addiDescrip;
        this.addiprice = addiprice;
    }

    paint(){
        
    }
}