class screenDessert{
    constructor(){

    }

    paint(){
        image(g,0,0,width,height);
    }

    
}