class ScreenOrder{
    constructor(){
        
    }

    IncludeAddition(){

    }

    totalPrice(){

    }

    paint(){
        image(h,0,0,width, height);
    }
}