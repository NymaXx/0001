class screenFast{
    constructor(){

    }

    paint(){
        image(f,0,0,width,height);
    }

    
}