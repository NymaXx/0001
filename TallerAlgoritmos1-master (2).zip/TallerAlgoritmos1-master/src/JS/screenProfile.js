class screenProfile{
    constructor(){

    }

    paint(){
        image(d,0,0, width, height);
    }


    
}