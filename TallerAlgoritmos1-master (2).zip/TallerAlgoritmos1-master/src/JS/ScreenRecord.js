class ScreenRecord extends ScreenOrder{
    constructor(){
        
    }

    paint(){
        image(l,0,0,width,height);
        }
}