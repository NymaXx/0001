class Modal{
    constructor(){

    }

    paint(){
        image(j, 0,0, width, height);
    }

    closeModal1(){
        
    }

    paint2(){
        image(m,0,0,width,height);
    }

    closeModal2(){
        
    }

    
}