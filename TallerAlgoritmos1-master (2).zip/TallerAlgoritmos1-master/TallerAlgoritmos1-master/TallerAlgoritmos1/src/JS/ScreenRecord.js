class ScreenRecord{
    constructor(){
        
    }

    paint(){
        image(l,0,0,width,height);
        }
}